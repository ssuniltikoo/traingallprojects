package com.boot.pan.startup;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

/*
 * http://localhost:8083/validatePAN/11111AAAAA
 */

@SpringBootApplication
@ComponentScan(basePackages={"com.boot.pan"})
@EntityScan(basePackages={"com.boot.pan.entities"})
public class SprinBootStartup {
	
	public static void main(String[] args) {
		SpringApplication.run(SprinBootStartup.class, args);
	}
}
