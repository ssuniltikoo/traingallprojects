package com.boot.pan.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.boot.pan.entities.PanDetails;
import com.boot.pan.exceptions.PanException;

@Repository("dao")
public class PanDaosImpl implements PanDaos {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public boolean panVerification(String panNo) throws PanException {
		boolean panStatus = false;
		System.out.println(panNo);
		System.out.println(panNo+"In DAO");
		Query query = entityManager.createQuery("select p from PAN p where p.panNo = :panNo");
		query.setParameter("panNo", panNo);
		PanDetails epc = (PanDetails) query.getSingleResult();
		//PanDetails epc = entityManager.find(PanDetails.class, panNo);
		
		System.out.println(epc);
		if (epc.getPanNo() != null && epc.getActive().equals("TRUE")) {
			panStatus = true;
		}
		return panStatus;
	}

	@Override
	public List<PanDetails> getPanList() throws PanException {
		// TODO Auto-generated method stub
		return entityManager.createQuery("from PanDetails").getResultList();
	}
}
