package com.boot.pan.exceptions;

public class PanException extends Exception {
	

		public PanException(String message, Throwable cause) {
			super(message, cause);
		}

		public PanException(String message) {
			super(message);
		}
	}

