package com.boot.pan.service;

import java.util.List;

import com.boot.pan.entities.PanDetails;
import com.boot.pan.exceptions.PanException;

public interface PanService {
	public boolean panVerification(String panNo) throws PanException;
	public List<PanDetails> getPanList() throws PanException;
}
