package com.boot.pan.daos;

import java.util.List;

import com.boot.pan.entities.PanDetails;
import com.boot.pan.exceptions.PanException;

public interface PanDaos {
	
	public boolean panVerification(String panNo) throws PanException;
	public List<PanDetails> getPanList() throws PanException;
}
