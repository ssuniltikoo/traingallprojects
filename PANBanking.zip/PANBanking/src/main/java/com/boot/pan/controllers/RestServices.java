package com.boot.pan.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.boot.pan.entities.PanDetails;
import com.boot.pan.exceptions.PanException;
import com.boot.pan.service.PanService;

@RestController
@CrossOrigin(origins = "*", methods={RequestMethod.POST, RequestMethod.GET, RequestMethod.PUT, RequestMethod.DELETE}
,allowedHeaders="*")
//@RequestMapping("/validatePAN")
public class RestServices {

	@Autowired
	@Qualifier("panService")
	private PanService panService;

	public RestServices() {
		System.out.println("Bean created.");
	}

	@GetMapping(value = "validatePAN/{panNo}")
	public boolean panVerification(@PathVariable("panNo") String panNo) {
		System.out.println(panNo+"Not Working");
		boolean pFlag = false;
		
		try {
			pFlag = panService.panVerification(panNo);
			System.out.println(pFlag);
		} catch (PanException e) {

			e.printStackTrace();
		}
		return pFlag;

	}
	@GetMapping(value="",produces="application/json")
	public List<PanDetails> getAllPans() throws PanException{
			return panService.getPanList();
	}
}
