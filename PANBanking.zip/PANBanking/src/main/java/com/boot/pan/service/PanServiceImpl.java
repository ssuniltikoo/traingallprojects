package com.boot.pan.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.boot.pan.daos.PanDaos;
import com.boot.pan.entities.PanDetails;
import com.boot.pan.exceptions.PanException;

@Service("panService")
public class PanServiceImpl implements PanService{
	private PanDaos dao;

	@Autowired
	public PanServiceImpl(@Qualifier("dao") PanDaos dao) {
		this.dao=dao;
	}
	
	@Override
	public boolean panVerification(String panNo) throws PanException {
		
		return dao.panVerification(panNo);
	}

	@Override
	public List<PanDetails> getPanList() throws PanException {
		// TODO Auto-generated method stub
		return dao.getPanList();
	}
}
