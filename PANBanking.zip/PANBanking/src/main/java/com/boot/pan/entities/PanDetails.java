package com.boot.pan.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="PAN")
@Table(name = "PAN_DETAILS")
public class PanDetails implements Serializable {

	private static final long serialVersionUID = -5213780404359946430L;

	private String panNo;
	private String active;

	public PanDetails() {
		// TODO Auto-generated constructor stub
	}
	
	@Id
	@Column(name = "PANNO")
	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	@Column(name = "Active")
	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "PanDetails [panNo=" + panNo + ", active=" + active + "]";
	}

}
